
from distutils.core import setup
setup(
    name='feelings',
    version='1.0.1',
    py_modules=['feelings'],
    author='crooner',
    author_email='zhunianhhxy@163.com',
    url='https://github.com/whcm-coding/python-course',
    description='A simple example of python package'
)
