def say_to_my_teacher():
    print('I hate python!')
